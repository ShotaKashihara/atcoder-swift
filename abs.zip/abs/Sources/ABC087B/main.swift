// ABC087B - Coins
// https://atcoder.jp/contests/abs/tasks/abc087_b
// 実行制限時間: 2.0 sec
import Foundation

func solve(_ A: Int, _ B: Int, _ C: Int, _ X: Int) {
    // Write code here!
}

// =========================

let A = Int(readLine()!)!
let B = Int(readLine()!)!
let C = Int(readLine()!)!
let X = Int(readLine()!)!

solve(A, B, C, X)

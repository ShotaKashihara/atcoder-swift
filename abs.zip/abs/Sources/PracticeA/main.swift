// PracticeA - Welcome to AtCoder
// https://atcoder.jp/contests/abs/tasks/practice_1
// 実行制限時間: 2.0 sec
import Foundation

func solve(_ a: Int, _ b: Int, _ c: Int, _ s: String) {
    // Write code here!
}

// =========================

let a = Int(readLine()!)!
let (b, c): (Int, Int) = { let line = readLine()!.split(separator: " ").map(String.init); return (Int(line[0])!, Int(line[1])!) }()
let s = readLine()!

solve(a, b, c, s)

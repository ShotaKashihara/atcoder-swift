// ABC085C - Otoshidama
// https://atcoder.jp/contests/abs/tasks/abc085_c
// 実行制限時間: 2.0 sec
import Foundation

func solve(_ N: Int, _ Y: Int) {
    // Write code here!
}

// =========================

let N = Int(readLine()!)!
let Y = Int(readLine()!)!

solve(N, Y)

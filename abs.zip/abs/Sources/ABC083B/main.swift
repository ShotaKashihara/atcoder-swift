// ABC083B - Some Sums
// https://atcoder.jp/contests/abs/tasks/abc083_b
// 実行制限時間: 2.0 sec
import Foundation

func solve(_ N: Int, _ A: Int, _ B: Int) {
    // Write code here!
}

// =========================

let N = Int(readLine()!)!
let A = Int(readLine()!)!
let B = Int(readLine()!)!

solve(N, A, B)

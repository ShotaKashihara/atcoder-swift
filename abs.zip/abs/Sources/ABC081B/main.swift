// ABC081B - Shift only
// https://atcoder.jp/contests/abs/tasks/abc081_b
// 実行制限時間: 2.0 sec
import Foundation

func solve(_ N: Int, _ A: [Int]) {
    // Write code here!
}

// =========================

let N = Int(readLine()!)!
let A = readLine()!.split(separator: " ").map(String.init).map { Int($0)! }

solve(N, A)

// ABC086A - Product
// https://atcoder.jp/contests/abs/tasks/abc086_a
// 実行制限時間: 2.0 sec
import Foundation

func solve(_ a: Int, _ b: Int) {
    // Write code here!
}

// =========================

let a = Int(readLine()!)!
let b = Int(readLine()!)!

solve(a, b)

// ABC085B - Kagami Mochi
// https://atcoder.jp/contests/abs/tasks/abc085_b
// 実行制限時間: 2.0 sec
import Foundation

func solve(_ N: Int, _ d: [Int]) {
    // Write code here!
}

// =========================

let N = Int(readLine()!)!
let d = (0..<N).map { _ in Int(readLine()!)! }

solve(N, d)

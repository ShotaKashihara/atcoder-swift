// ABC081A - Placing Marbles
// https://atcoder.jp/contests/abs/tasks/abc081_a
// 実行制限時間: 2.0 sec
import Foundation

func solve(_ s: String) {
    // Write code here!
}

// =========================

let s = readLine()!

solve(s)

// ABC088B - Card Game for Two
// https://atcoder.jp/contests/abs/tasks/abc088_b
// 実行制限時間: 2.0 sec
import Foundation

func solve(_ N: Int, _ a: [Int]) {
    // Write code here!
}

// =========================

let N = Int(readLine()!)!
let a = readLine()!.split(separator: " ").map(String.init).map { Int($0)! }

solve(N, a)

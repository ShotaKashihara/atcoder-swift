# [AtCoder Beginners Selection](https://atcoder.jp/contests/abs)

問題名 | 実行時間制限 | メモリ制限
:-- | --: | --:
[ABC049C Daydream](https://atcoder.jp/contests/abs/tasks/arc065_a) | 2.0 sec | 256 MB
[ABC081A Placing Marbles](https://atcoder.jp/contests/abs/tasks/abc081_a) | 2.0 sec | 256 MB
[ABC081B Shift only](https://atcoder.jp/contests/abs/tasks/abc081_b) | 2.0 sec | 256 MB
[ABC083B Some Sums](https://atcoder.jp/contests/abs/tasks/abc083_b) | 2.0 sec | 256 MB
[ABC085B Kagami Mochi](https://atcoder.jp/contests/abs/tasks/abc085_b) | 2.0 sec | 256 MB
[ABC085C Otoshidama](https://atcoder.jp/contests/abs/tasks/abc085_c) | 2.0 sec | 256 MB
[ABC086A Product](https://atcoder.jp/contests/abs/tasks/abc086_a) | 2.0 sec | 256 MB
[ABC086C Traveling](https://atcoder.jp/contests/abs/tasks/arc089_a) | 2.0 sec | 256 MB
[ABC087B Coins](https://atcoder.jp/contests/abs/tasks/abc087_b) | 2.0 sec | 256 MB
[ABC088B Card Game for Two](https://atcoder.jp/contests/abs/tasks/abc088_b) | 2.0 sec | 256 MB
[PracticeA Welcome to AtCoder](https://atcoder.jp/contests/abs/tasks/practice_1) | 2.0 sec | 256 MB
